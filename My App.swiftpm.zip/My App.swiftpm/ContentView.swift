//By Kevin Kelly

import SwiftUI

struct ContentView: View {
    
    let names = ["Chevrolet", "Ford", "Dodge", "GMC", "Cadillac"]
    
    
    var body: some View {
        NavigationView{
            List{
                Text("What make of car?")
                    .font(.largeTitle)
                    .foregroundColor(.red)
                ForEach(names, id: \.self) { name in 
                    Button {
                        //??
                    } label: {Text(name)
                    }
                    //Image(systemName: "car")
                    //  .imageScale(.large)
                    //.foregroundColor(.accentColor)
                    
                    }
                    .navigationTitle("Parts Finder")
                }
                .navigationViewStyle(.stack)
                
                
        }  
    }
}
